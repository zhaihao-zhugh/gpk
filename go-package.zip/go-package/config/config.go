package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"package/log"
	"strings"

	"gopkg.in/yaml.v2"
)

var (
	ErrNoMatchField = errors.New("no match field")
)

type Config struct {
	Value    map[string]map[string]interface{} //当前值,优先级：动态修改值>环境变量>配置文件>defaultYaml>全局配置>默认值
	Modify   any                               //动态修改的值
	Env      any                               //环境变量中的值
	File     any                               //配置文件中的值
	Default  any                               //默认值
	name     string                            // 小写
	propsMap map[string]*Config
	props    []*Config
}

var (
	Global *Config
)

func ReadConfig(conf any) (err error) {
	if Global == nil {
		Global = &Config{
			name: "global",
		}
	}
	var t string
	var cg map[string]map[string]interface{}
	var raw []byte
	switch v := conf.(type) {
	case string:
		if raw, err = os.ReadFile(v); err != nil {
			return
		}
		_, t, _ = strings.Cut(v, ".")
	case []byte:
		raw = v
	case map[string]map[string]interface{}:
		cg = v
	}
	if raw != nil {
		switch t {
		case "json":
			if err = json.Unmarshal(raw, &cg); err != nil {
				return
			}
		case "yaml":
			if err = yaml.Unmarshal(raw, &cg); err != nil {
				return
			}
		}
	}
	if cg != nil {
		Global.Value = cg
	}
	log.Debugf("config: %+v", Global.Value)
	return
}

func (config *Config) Get(key string) (v *Config) {
	if config.propsMap == nil {
		config.propsMap = make(map[string]*Config)
	}
	if v, ok := config.propsMap[key]; ok {
		return v
	} else {
		v = &Config{
			name: key,
		}
		config.propsMap[key] = v
		config.props = append(config.props, v)
		return v
	}
}

func (config *Config) GetValue(key ...string) any {
	if config == nil {
		return nil
	}
	switch len(key) {
	case 1:
		if v, ok := config.Value[key[0]]; ok {
			return v
		}
		return nil
	case 2:
		if v, ok := config.Value[key[0]]; ok {
			if vv, ok := v[key[1]]; ok {
				return vv
			}
			return nil
		}
		return nil
	}
	return nil
}

func (config *Config) GetString(key ...string) string {
	var res string
	if config == nil {
		return res
	}
	if len(key) != 2 {
		return res
	}

	if v, ok := config.Value[key[0]]; ok {
		if vv, ok := v[key[1]].(string); ok {
			res = vv
		}
	}
	fmt.Println("GetString", res)
	return res
}

func (config *Config) Parse(name string, cfg any) error {
	if v, ok := config.Value[name]; ok {
		v_byte, err := json.Marshal(v)
		if err != nil {
			return err
		}
		log.Debug(string(v_byte))
		return json.Unmarshal(v_byte, cfg)
	}
	return ErrNoMatchField
}

func Read(path string, conf any) error {
	if raw, err := os.ReadFile(path); err != nil {
		return err
	} else {
		if _, t, ok := strings.Cut(path, "."); ok {
			switch t {
			case "json":
				if err = json.Unmarshal(raw, conf); err != nil {
					return err
				}
			case "yaml":
				if err = yaml.Unmarshal(raw, conf); err != nil {
					return err
				}
			}
		}
	}
	return nil
}
