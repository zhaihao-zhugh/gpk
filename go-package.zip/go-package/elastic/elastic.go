package elastic

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"package/log"
	"time"

	"github.com/elastic/go-elasticsearch/v8"
	"github.com/elastic/go-elasticsearch/v8/esapi"
)

// var es *elasticsearch.Client

type EsConfig struct {
	Host []string `json:"host"`
}

type EsClient struct {
	es     *elasticsearch.Client
	config *elasticsearch.Config
}

func NewConnect(host ...string) (client *EsClient, err error) {
	cfg := elasticsearch.Config{
		Addresses:     host,
		RetryOnStatus: []int{502, 503, 504, 429},
		RetryOnError: func(r *http.Request, e error) bool {
			if e != nil {
				log.Error(e)
				time.Sleep(5 * time.Second)
			}
			return true
		},
	}
	cli, e := elasticsearch.NewClient(cfg)
	if e != nil {
		err = e
		return
	}

	client = &EsClient{
		es:     cli,
		config: &cfg,
	}
	return
}

func (c *EsClient) HandleESDefine(index string, body io.Reader) (result []byte, err error) {
	req := esapi.IndicesCreateRequest{
		Index: index, // Index name
		Body:  body,  // Document body
	}
	res, e := req.Do(context.Background(), c.es)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	result, err = io.ReadAll(res.Body)
	return
}

func (c *EsClient) Create(index string, id string, body io.Reader) (result []byte, err error) {
	res, e := c.es.Index(
		index,                          // Index name
		body,                           // Document body
		c.es.Index.WithDocumentID(id),  // Document ID
		c.es.Index.WithRefresh("true"), // Refresh
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	result, err = io.ReadAll(res.Body)
	return
}

func (c *EsClient) Search(body io.Reader, index ...string) (result []byte, err error) {
	res, e := c.es.Search(
		c.es.Search.WithContext(context.Background()),
		c.es.Search.WithIndex(index...),
		c.es.Search.WithBody(body),
		c.es.Search.WithTrackTotalHits(true),
		c.es.Search.WithPretty(),
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	result, e = io.ReadAll(res.Body)
	if e != nil {
		err = e
		return
	}
	return
}

func (c *EsClient) Update(index string, doc_id string, body io.Reader) (result bool, err error) {
	res, e := c.es.Update(
		index,
		doc_id,
		body,
		c.es.Update.WithRefresh(`true`),
		c.es.Update.WithPretty(),
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	if res.StatusCode == 200 {
		result = true
		return
	}
	err = errors.New("es update fail")
	return
}

func (c *EsClient) UpdateByQuery(indexes []string, body io.Reader) (result bool, err error) {
	res, e := c.es.UpdateByQuery(
		indexes,
		c.es.UpdateByQuery.WithBody(body),
		c.es.UpdateByQuery.WithRefresh(true),
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	if res.StatusCode == 200 {
		result = true
		return
	}
	err = errors.New("es update fail")
	return
}

func (c *EsClient) DeleteById(index string, doc_id string) (result bool, err error) {
	res, e := c.es.Delete(
		index,
		doc_id,
		c.es.Delete.WithRefresh("true"),
	)
	if e != nil {
		err = e
		return
	}
	// defer res.Body.Close()
	if res.StatusCode == 200 {
		result = true
		return
	}
	err = errors.New("es delete fail")
	return
}

func (c *EsClient) DeleteByQuery(indexes []string, body io.Reader) (result bool, err error) {
	res, e := c.es.DeleteByQuery(
		indexes,
		body,
		c.es.DeleteByQuery.WithRefresh(true),
	)
	if e != nil {
		err = e
		return
	}
	if res.StatusCode == 200 {
		result = true
		return
	}
	err = errors.New("es delete fail")
	return
}

func (c *EsClient) Get(index string, doc_id string) (result []byte, err error) {
	res, e := c.es.Get(
		index,
		doc_id,
		c.es.Get.WithPretty(),
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		err = errors.New("no data")
		return
	}
	result, err = io.ReadAll(res.Body)
	return
}

func (c *EsClient) State(index string, field string) (result []byte, err error) {
	res, e := c.es.Indices.Stats(
		c.es.Indices.Stats.WithIndex(index),
		c.es.Indices.Stats.WithMetric(field),
	)
	if e != nil {
		err = e
		return
	}
	defer res.Body.Close()
	if res.StatusCode != 200 {
		err = errors.New("status code error")
		return
	}
	result, err = io.ReadAll(res.Body)
	return
}

func (c *EsClient) Count(index string, body io.Reader) int {
	var res *esapi.Response
	var err error
	if body != nil {
		res, err = c.es.Count(
			c.es.Count.WithContext(context.Background()),
			c.es.Count.WithIndex(index),
			c.es.Count.WithBody(body),
			c.es.Count.WithPretty(),
		)
	} else {
		res, err = c.es.Count(
			c.es.Count.WithContext(context.Background()),
			c.es.Count.WithIndex(index),
			c.es.Count.WithPretty(),
		)
	}
	if err != nil {
		return 0
	}
	defer res.Body.Close()
	res_body, err := io.ReadAll(res.Body)
	if err != nil {
		return 0
	}
	result := make(map[string]interface{})
	json.Unmarshal(res_body, &result)

	if count, ok := result["count"].(float64); ok {
		return int(count)
	}
	return 0
}

func (c *EsClient) IsHaveValue(index string, filter map[string]interface{}) bool {
	req := map[string]interface{}{
		"query": map[string]interface{}{
			"match": filter,
		},
	}
	var b bytes.Buffer
	json.NewEncoder(&b).Encode(req)
	// req_json, _ := json.Marshal(req)
	// body := bytes.NewBuffer(req_json)
	count := c.Count(index, &b)
	return count > 0
}
