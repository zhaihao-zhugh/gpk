package rabbitmq

type PublishMsg struct {
	Exchange string      `json:"exchange"`
	Key      string      `json:"key"`
	Body     interface{} `json:"body"`
}

type Msg struct {
	Action string      `json:"action"`
	Data   interface{} `json:"data"`
}

type BasicCUDA struct {
	Table  string `json:"table"`
	Action string `json:"action"`
	IDs    []int  `json:"ids"`
}

const (
	ActionDatabaseModify    = "database.modify"
	ActionLinkageFront      = "linkage.front.action"
	ActionTaskResult        = "task.result.final"
	ActionFrontAcpointValue = "front.acpoint.value"
	ActionFrontAcpointAlarm = "front.acpoint.alarm"
)
