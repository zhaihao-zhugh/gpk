package tcp_server

import "net"

type TcpServer struct {
	listenAddr *net.TCPAddr
	listener   *net.TCPListener
}
