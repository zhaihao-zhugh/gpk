package tool

import "time"

func TimeFormate(origin_time string) string {
	default_str := time.Now().Format(time.DateTime)

	if origin_time == "" {
		return default_str
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.Parse(time.DateTime, origin_time)
		if err == nil {
			return parse_str_time.Format(time.DateTime)
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.Parse("20060102 15:04:05", origin_time)
		if err == nil {
			return parse_str_time.Format(time.DateTime)
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.Parse("2006-01-02T15:04:05", origin_time)
		if err == nil {
			return parse_str_time.Format(time.DateTime)
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.Parse(time.RFC3339, origin_time)
		if err == nil {
			return parse_str_time.Format(time.DateTime)
		}
	}

	return default_str
}
func StringToTime(origin_time string) time.Time {
	default_time := time.Now()
	if origin_time == "" {
		return time.Time{}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.ParseInLocation(time.DateTime, origin_time, time.Local)
		if err == nil {
			return parse_str_time
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.ParseInLocation("20060102 15:04:05", origin_time, time.Local)
		if err == nil {
			return parse_str_time
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.ParseInLocation("2006-01-02T15:04:05", origin_time, time.Local)
		if err == nil {
			return parse_str_time
		}
	}

	{
		var parse_str_time time.Time
		parse_str_time, err := time.ParseInLocation(time.RFC3339, origin_time, time.Local)
		if err == nil {
			return parse_str_time
		}
	}

	return default_time
}
